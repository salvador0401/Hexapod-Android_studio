package com.example.controlbluetooth;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.app.VoiceInteractor;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.ingenieriajhr.blujhr.BluJhr;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_SPEECH_INPUT = 1000;
    BluJhr blue;
    List<String> requiredPermissions;
    ArrayList<String> devicesBluetooth = new ArrayList<String>();
    ConstraintLayout viewConn;
    ListView listDeviceBluetooth;
    ImageButton Up,Down,Left,Right,Home,UL,UR,DL,DR,GiroIz,GiroDr,Voz;
    String[] comandos={"avanza","retrocede","izquierda","derecha","home","avanza por la izquierda","avanza por la derecha","retrocede por la izquierda","retrocede por la derecha","Gira a la derecha","Gira a la izquierda"};
    TextView consola,prueba;
    Boolean voz=false,send=false;
    final boolean[] isButtonPressed = {false};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        blue = new BluJhr(this);
        blue.onBluetooth();

        final int[] x = {1000};
        listDeviceBluetooth = findViewById(R.id.listDeviceBluetooth);
        viewConn = findViewById(R.id.viewConn);
        Up = findViewById(R.id.Up);
        prueba = findViewById(R.id.prueba);
        Down = findViewById(R.id.Down);
        Left = findViewById(R.id.Left);
        Right = findViewById(R.id.Right);
        Home = findViewById(R.id.Home);
        UL = findViewById(R.id.UL);
        UR = findViewById(R.id.UR);
        DL = findViewById(R.id.DL);
        DR = findViewById(R.id.DR);
        GiroIz = findViewById(R.id.GiroIz);
        GiroDr= findViewById(R.id.GiroDr);
        Voz= findViewById(R.id.Voz);

        listDeviceBluetooth.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (!devicesBluetooth.isEmpty()){
                    blue.connect(devicesBluetooth.get(i));
                    blue.setDataLoadFinishedListener(new BluJhr.ConnectedBluetooth() {
                        @Override
                        public void onConnectState(@NonNull BluJhr.Connected connected) {
                            if (connected == BluJhr.Connected.True){
                                Toast.makeText(getApplicationContext(),"True",Toast.LENGTH_SHORT).show();
                                listDeviceBluetooth.setVisibility(View.GONE);
                                viewConn.setVisibility(View.VISIBLE);
                                rxReceived();
                            }else{
                                if (connected == BluJhr.Connected.Pending){
                                    Toast.makeText(getApplicationContext(),"Pending",Toast.LENGTH_SHORT).show();
                                }else{
                                    if (connected == BluJhr.Connected.False){
                                        Toast.makeText(getApplicationContext(),"False",Toast.LENGTH_SHORT).show();
                                    }else{
                                        if (connected == BluJhr.Connected.Disconnect){
                                            Toast.makeText(getApplicationContext(),"Disconnect",Toast.LENGTH_SHORT).show();
                                            listDeviceBluetooth.setVisibility(View.VISIBLE);
                                            viewConn.setVisibility(View.GONE);
                                        }
                                    }
                                }
                            }
                        }
                    });
                }
            }
        });

      /*  buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                blue.bluTx(edtTx.getText().toString());
            }
        });*/
//Up,Down,Left,Right,Home,UL,UR,DL,DR,GiroIz,GiroDr,Voz;

        GiroDr.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    // Se presionó el botón
                    isButtonPressed[0] = true;
                    x[0] =10;
                    voz=false;
                    startSendingData(x[0]);
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    // Se soltó el botón
                  //  startSendingData(4);
                    isButtonPressed[0] = false;
                }

                return false;
            }
        });
        GiroIz.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    // Se presionó el botón
                    isButtonPressed[0] = true;
                    x[0] =9;
                    voz=false;
                    startSendingData(x[0]);
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    // Se soltó el botón
                   // startSendingData(4);
                    isButtonPressed[0] = false;
                }

                return false;
            }
        });
        DR.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    // Se presionó el botón
                    isButtonPressed[0] = true;
                    x[0] =8;
                    voz=false;
                    startSendingData(x[0]);
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    // Se soltó el botón
                    //startSendingData(4);
                    isButtonPressed[0] = false;
                }

                return false;
            }
        });
        DL.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    // Se presionó el botón
                    isButtonPressed[0] = true;
                    x[0] =7;
                    voz=false;
                    startSendingData(x[0]);
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    // Se soltó el botón
                   // startSendingData(4);
                    isButtonPressed[0] = false;
                }

                return false;
            }
        });
        UR.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    // Se presionó el botón
                    isButtonPressed[0] = true;
                    x[0] =6;
                    voz=false;
                    startSendingData(x[0]);
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    // Se soltó el botón
                   // startSendingData(4);
                    isButtonPressed[0] = false;
                }

                return false;
            }
        });
        UL.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    // Se presionó el botón
                    isButtonPressed[0] = true;
                    x[0] =5;
                    voz=false;
                    startSendingData(x[0]);
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    // Se soltó el botón
                 //   startSendingData(4);
                    isButtonPressed[0] = false;
                }

                return false;
            }
        });
        Home.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    // Se presionó el botón
                    isButtonPressed[0] = true;
                    x[0] =4;
                    voz=false;
                    startSendingData(x[0]);
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    // Se soltó el botón
                   // startSendingData(4);
                    isButtonPressed[0] = false;
                }

                return false;
            }
        });
        Right.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    // Se presionó el botón
                    isButtonPressed[0] = true;
                    x[0] =3;
                    voz=false;
                    startSendingData(x[0]);
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    // Se soltó el botón
                    //startSendingData(4);
                    isButtonPressed[0] = false;
                }

                return false;
            }
        });
        Left.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    // Se presionó el botón
                    isButtonPressed[0] = true;
                    x[0] =2;
                    voz=false;
                    startSendingData(x[0]);
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    // Se soltó el botón
                   // startSendingData(4);
                    isButtonPressed[0] = false;
                }

                return false;
            }
        });
        Down.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    // Se presionó el botón
                    isButtonPressed[0] = true;
                    x[0] =1;
                    startSendingData(99);
                    try {
                        Thread.sleep(100); // Espera por 2 segundos
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    startSendingData(x[0]);
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    // Se soltó el botón
                   // startSendingData(4);
                    isButtonPressed[0] = false;
                }

                return false;
            }
        });
        Up.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    // Se presionó el botón
                    isButtonPressed[0] = true;
                    x[0] =0;
                    startSendingData(99);
                    try {
                        Thread.sleep(100); // Espera por 2 segundos
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    startSendingData(x[0]);
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    // Se soltó el botón
                   // startSendingData(4);
                    isButtonPressed[0] = false;

                }

                return false;
            }
        });
        Voz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //voz=false;
                Speak();
            }
        });


    }
    private void Speak()
    {

        Intent intent =new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
    //    intent.putExtra(RecognizerIntent.EXTRA_PROMPT,"Dile que hacer a la Bichota");
        try {

            startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT);


        }
        catch(Exception e)
        {
            Toast.makeText(this,""+e.getMessage(),Toast.LENGTH_SHORT).show();
        }


    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if (!blue.stateBluetoooth() && requestCode == 100){
            blue.initializeBluetooth();
        }else{
            if (requestCode == 100){
                devicesBluetooth = blue.deviceBluetooth();
                if (!devicesBluetooth.isEmpty()){
                    ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_expandable_list_item_1,devicesBluetooth);
                    listDeviceBluetooth.setAdapter(adapter);
                }else{
                    Toast.makeText(this, "No tienes vinculados dispositivos", Toast.LENGTH_SHORT).show();
                }

            }
        }
        if(requestCode==REQUEST_CODE_SPEECH_INPUT)
        {
            //startSendingData(99);
            ArrayList<String> result=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
           // prueba.setText(result.get(0));
            Map<String, Runnable> comando = new HashMap<>();

            comando.put("avanza", () -> {

                prueba.setText(result.get(0));
                startSendingData(99);

                try {
                    Thread.sleep(100); // Espera por 2 segundos
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                voz=true;
                startSendingData(0);


            });
            comando.put("retrocede", () -> {

                prueba.setText(result.get(0));
                startSendingData(99);
                try {
                    Thread.sleep(100); // Espera por 2 segundos
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                voz=true;
                startSendingData(1);

            });
            comando.put("izquierda", () -> {

                prueba.setText(result.get(0));
                startSendingData(99);
                try {
                    Thread.sleep(100); // Espera por 2 segundos
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                voz=true;
                startSendingData(2);

            });
            comando.put("derecha", () -> {

                prueba.setText(result.get(0));
                startSendingData(99);
                try {
                    Thread.sleep(100); // Espera por 2 segundos
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                voz=true;
                startSendingData(3);

            });
            comando.put("home", () -> {

                prueba.setText(result.get(0));
                startSendingData(99);
                try {
                    Thread.sleep(100); // Espera por 2 segundos
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                voz=true;
                startSendingData(4);

            });
            comando.put("avanza por la izquierda", () -> {
                startSendingData(99);
                try {
                    Thread.sleep(100); // Espera por 2 segundos
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                voz=true;
                startSendingData(5);

            });
            comando.put("avanza por la derecha", () -> {

                prueba.setText(result.get(0));
                startSendingData(99);
                try {
                    Thread.sleep(100); // Espera por 2 segundos
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                voz=true;
                startSendingData(6);

            });
            comando.put("retrocede por la izquierda", () -> {

                startSendingData(99);
                try {
                    Thread.sleep(100); // Espera por 2 segundos
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                voz=true;
                startSendingData(7);

            });
            comando.put("retrocede por la derecha", () -> {

                startSendingData(99);
                try {
                    Thread.sleep(100); // Espera por 2 segundos
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                voz=true;
                startSendingData(8);

            });
            comando.put("Gira a la derecha", () -> {

                startSendingData(99);
                try {
                    Thread.sleep(100); // Espera por 2 segundos
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                voz=true;
                startSendingData(10);
            });
            comando.put("Gira a la izquierda", () -> {

                startSendingData(99);
                try {
                    Thread.sleep(100); // Espera por 2 segundos
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                voz=true;
                startSendingData(9);
            });
            comando.put("baila", () -> {

                startSendingData(99);
                try {
                    Thread.sleep(100); // Espera por 2 segundos
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                voz=true;
                startSendingData(11);
            });
            comando.put("saluda", () -> {
                startSendingData(99);
                try {
                    Thread.sleep(100); // Espera por 2 segundos
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                voz=true;
                startSendingData(12);
            });
            comando.put("modo ataque", () -> {

                startSendingData(99);
                try {
                    Thread.sleep(100); // Espera por 2 segundos
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                voz=true;
                startSendingData(13);
            });
            comando.put("para", () -> {

                prueba.setText(result.get(0));

                voz=true;
                startSendingData(99);
            });
            Runnable accion =comando.getOrDefault(result.get(0), () -> {
                Toast.makeText(this, "Comando no identificado", Toast.LENGTH_SHORT).show();
                //voz=true;
            });

            accion.run();


        }

        super.onActivityResult(requestCode, resultCode, data);
    }


    private void startSendingData(int n) {
        // Este hilo se ejecutará mientras el botón esté presionado
        new Thread(new Runnable() {
            @Override
            public void run() {

                while (isButtonPressed[0]||voz) {
                    // Envía tus datos Bluetooth aquí
                    // por ejemplo: enviarDatosBluetooth();
                    // Simulación de espera antes de enviar el próximo dato
                    //Up,Down,Left,Right,Home,UL,UR,DL,DR,GiroIz,GiroDr,Voz;
                    switch (n)
                    {
                        case 0:
                            blue.bluTx("Y");
                            break;
                        case 1:
                            blue.bluTx("X");
                            break;
                        case 2:
                            blue.bluTx("A");
                            break;
                        case 3:
                            blue.bluTx("O");
                            break;
                        case 4:
                            blue.bluTx("H");
                            voz=false;
                            break;
                        case 5:
                            blue.bluTx("L");
                            break;
                        case 6:
                            blue.bluTx("U");
                            break;
                        case 7:
                            blue.bluTx("D");
                            break;
                        case 8:
                            blue.bluTx("R");
                            break;
                        case 9:
                            blue.bluTx("P");
                            break;
                        case 10:
                            blue.bluTx("W");
                            break;
                        case 11:
                            blue.bluTx("T");
                            break;
                        case 12:
                            blue.bluTx("F");
                            break;
                        case 13:
                            blue.bluTx("Q");
                            voz=false;
                            break;
                        case 99:
                            voz=false;
                            break;



                    }

                    try {
                        Thread.sleep(70); // Puedes ajustar este valor según tus necesidades
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }
    private void rxReceived() {

        blue.loadDateRx(new BluJhr.ReceivedData() {
            @Override
            public void rxDate(@NonNull String s) {
                consola.setText(consola.getText().toString()+s);
            }
        });

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (blue.checkPermissions(requestCode,grantResults)){
            Toast.makeText(this, "Exit", Toast.LENGTH_SHORT).show();
            blue.initializeBluetooth();
        }else{
            if(Build.VERSION.SDK_INT < Build.VERSION_CODES.S){
                blue.initializeBluetooth();
            }else{
                Toast.makeText(this, "Algo salio mal", Toast.LENGTH_SHORT).show();
            }
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }



 }